//export const BASEURL = "http://localhost:8088"
export const BASEURL = "https://eisaidigitalposterapi.netcastservice.co.in"
